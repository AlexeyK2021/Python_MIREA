from setuptools import setup

setup(
    name='Experimental',
    version='1.1',
    packages=['Package'],
    url='no',
    license='not yet',
    author='Alexey Kalashnikov',
    author_email='',
    description='',
    data_files=['Package/file.json']
)
